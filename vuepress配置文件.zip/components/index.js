import FlipClock from './FlipClock.vue'

export default FlipClock
