---
# 当前页面内容标题
title: 书籍资源
# 当前页面图标
icon: animation
# 分类
category:
  - 书籍
# 标签
tag:
  - 书籍
sticky: false
# 是否收藏在博客主题的文章列表中，当填入数字时，数字越大，排名越靠前。
star: false
# 是否将该文章添加至文章列表中
article: true
# 是否将该文章添加至时间线中
timeline: true
---

| 资源名称                                   | 分享链接                                  |
| ------------------------------------------ | ----------------------------------------- |
| `《Labuladong的算法小抄》`                 | https://www.aliyundrive.com/s/8ouAjxFVgUX |
| `《小傅哥的IDEA插件开发手册》`             | https://www.aliyundrive.com/s/Pq7xVp9bXdR |
| `《疯狂Java讲义第四版》`                   | https://www.aliyundrive.com/s/Yd2L8XtGWUa |
| `《Java核心技术-卷1-基础知识》`            | https://www.aliyundrive.com/s/EvpXjq55LXn |
| `《Java核心技术-卷2-高级特性》`            | https://www.aliyundrive.com/s/hT5RQDe6q1k |
| `《Linux命令速查手册》`                    | https://www.aliyundrive.com/s/ophXiMFVPrB |
| `《鸟哥的Linux私房菜-高清》`               | https://www.aliyundrive.com/s/bd9PeqCf82N |
| `《鸟哥的Linux私房菜-非高清》`             | https://www.aliyundrive.com/s/e9ag9zBwTCS |
| `《数学建模算法与应用-第二版-司守奎》`     | https://www.aliyundrive.com/s/uDtSpLzFqz2 |
| `《统计学习方法-李航》`                    | https://www.aliyundrive.com/s/Gae5A3tJaZn |
| `《Matlab神经网络30个案例分析》`           | https://www.aliyundrive.com/s/EVibkTrcFex |
| `《具有AI功能加持的终端工具warp使用总结》` | https://www.aliyundrive.com/s/kXKqP4RqyUD |

